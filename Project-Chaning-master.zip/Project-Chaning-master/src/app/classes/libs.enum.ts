export enum Frameworks {
    None,
    angular2,
    react,
    jquery
}
