export const firebaseConfig = {
    apiKey: 'AIzaSyA2JyR-0J9bRaqaVrinigQ9eezFJw-pn9k',
    authDomain: 'project-chaining.firebaseapp.com',
    databaseURL: 'https://project-chaining.firebaseio.com',
    projectId: 'project-chaining',
    storageBucket: 'project-chaining.appspot.com',
    messagingSenderId: '1038175721513'
};
